# PV FFLS Digital-Twin Data-Admission Repository Materials (R6R1)

This repository bundle accompanies the double-blind conference manuscript:

**Physically Invalid Uncertainty from Valid PV Channels: Closure-Preserving Fuzzy Data Admission for Digital Twins**


## Upload status

This is the **R6R1 GitHub/Zenodo upload-ready repository bundle (2026-09-07 checked copy)**. It is prepared for either: (i) a private/anonymized review-support archive during double-blind review, or (ii) a public post-acceptance repository after author/institution approval.

Do **not** publish a named repository before checking the target venue's double-blind policy. Add final author names, affiliations, ORCID identifiers, accepted-paper citation, DOI, and an approved license only when appropriate.

## Scientific scope

R6R1 is a notation-closure cleanup of R6. It adds spread-scaling definitions, the explicit width functional, support-function definition, SWaT notation definitions, and derivative closure in the Supplement. It does not change any scientific result, dataset, numerical value, model structure, or main conclusion. RO/AI/desalination and arbitrary-FFLS-algorithm references are intentionally excluded per author instruction.


The repository supports the manuscript's reproducibility boundary: a PV digital-twin data-admission layer, not a complete digital twin, AI benchmark, fault detector, or controller. The primary field result is the PVDAQ 2107 mechanism audit and closure-preserving fuzzy alpha-cut certificate. The SWaT material is a bounded structural-transfer pilot only.

## Contents

- `manuscript_source/`: LaTeX source for the main paper and supplementary material.
- `figures/`: final figures used in the manuscript.
- `scripts/`: clean reproduction helpers for the PV state construction, width mechanism audit, alpha-cut certificate, and SWaT aggregate summary.
- `derived_results/pv/`: PV-derived tables, processed daily data, and mechanism-audit outputs.
- `derived_results/closure/`: closure-preserving alpha-cut and fuzzy-support outputs.
- `derived_results/swat/`: aggregate SWaT pilot results, hashes, and reports only.
- `evidence/`: supporting source-boundary notes.
- `environment/`: Python environment notes where available.

## Reproduction helpers

From the repository root, run:

```bash
python scripts/reproduce_pv_state.py
python scripts/reproduce_mechanism_widths.py
python scripts/reproduce_alpha_certificate.py
python scripts/summarize_swat_metrics.py
```

The scripts write JSON check files back into the relevant `derived_results/` subfolders.

## Data-access boundaries

The PV source is the public NREL/OEDI PVDAQ dataset cited in the manuscript. The processed daily PV table included here is a derived reproducibility artifact.

Raw SWaT data are **not redistributed**. Reproducing researchers must request their own authorized copy from iTrust, Centre for Research in Cyber Security, Singapore University of Technology and Design. This bundle includes only SWaT source hashes, code, aggregate derived results, and publication-ready figures.

## Author instructions before public release

1. Confirm double-blind policy for the target venue before publishing a named repository.
2. Select a repository host (GitHub + Zenodo DOI, Zenodo-only, OSF, or institutional repository).
3. Add final author names/affiliations only after blind-review constraints allow it.
4. Add a final license only after author/institution approval.
5. Never upload the raw SWaT spreadsheet or any redistributed copy of controlled SWaT data.
