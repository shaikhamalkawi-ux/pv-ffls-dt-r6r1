# SWaT A4/A5 bounded external structural-transfer pilot

## Role in the manuscript

This is an external test of the **structural-admission principle only**. It is not an external validation of the PV positive-FFLS / shared-latent alpha-cut construction, and it is not a cyberattack detector.

## Source object

Authorized SWaT A4/A5 July 2019 Version 2 physical historian, supplied through iTrust/SUTD. The source package documents a normal run from 12:35 PM to 2:50 PM GMT+8 on 20 July 2019, followed later by six labelled interventions. Its README states that spreadsheet timestamps are GMT+0 while the attack schedule is GMT+8.

The accompanying equipment glossary identifies T301 as the UF feedwater tank (capacity 1.8 m3; dimensions listed as 1.38 x 1.36), with LIT301 level instrumentation and FIT301 downstream flow instrumentation; FIT201 is the upstream raw-water-to-UF-feed-tank flow meter. The manuscript uses the dynamic T301 measurement object rather than forcing instantaneous inflow=outflow.

## Externally fixed invariant

Adepu and Mathur (AsiaCCS 2016, DOI 10.1145/2897845.2897855) publish the one-second invariant

`LIT301_model = LIT301_prev + 0.186428 * (FIT201 - FIT301)`.

The coefficient 0.186428 is fixed before opening the July 2019 result. It is not refitted in the primary analysis.

## Protocol

- Parse Version-2 historian timestamps as UTC.
- Use UTC-aligned nonoverlapping 60-second bins.
- Normal period: documented 04:35-06:50 UTC.
- Exclude the first minute after plant start as a startup transition.
- Require a complete 60 samples in a minute and a plausible timestamp span; one incomplete minute is excluded.
- Retain 133 complete attack-free normal windows.
- Observed level rate = `(last LIT301 - first LIT301) / elapsed seconds`.
- Predicted level rate = `0.186428 * mean(FIT201 - FIT301)`.
- Primary coefficient is fixed; a through-origin fit is reported only as sensitivity.

## Normal-run result

- complete 60-s windows: **133**
- fixed coefficient: **0.186428**
- R2 about the observed mean: **0.9846948322**
- median absolute residual: **0.0142314410 level units/s**
- mean absolute residual: **0.0211831702 level units/s**
- 95th-percentile absolute residual: **0.0616910248**
- 99th-percentile absolute residual: **0.0919624343**
- through-origin sensitivity fit: **0.1998383979** (+7.19% from the external published coefficient)

The sensitivity coefficient is not used for the primary result.

## Labelled disturbance stress check

The six later labelled intervals have heterogeneous residual behavior. The LIT301 spoof and the upstream MV201/P101 manipulation include windows that exceed the normal envelope, while P601 and P301 interventions do not. A stage-5 MV501 intervention, outside the T301 measurement boundary, also exceeds the normal envelope. Therefore exceedance is **not** interpreted as attack detection or localization. The transferred quantity is a physical admission/state-consistency residual only.

## Data-use restriction

The iTrust terms require explicit credit and prohibit sharing the dataset with others. Raw SWaT data are therefore excluded from this package. The package contains only source hashes, code, and aggregate derived results. Reproduction requires an independently authorized SWaT copy.
