# Closure-preserving fuzzy input definition

The fixed full-scale marginal triangular inputs already have centers and asymmetric spreads matching the empirical closure-support bounds. The issue is not the marginal numbers themselves; it is the missing joint dependence between complementary shares.

Define four latent triangular fuzzy variables \(	ilde p_1,	ilde p_2,	ilde b_1,	ilde b_2\) using the fixed centers and full-scale left/right spreads. Define the matrix through the deterministic map

\[
\widetilde A=egin{bmatrix}	ilde p_1&1-	ilde p_1\ 	ilde p_2&1-	ilde p_2\end{bmatrix},\qquad
\widetilde b=egin{bmatrix}	ilde b_1\ 	ilde b_2\end{bmatrix}.
\]

Thus \(A_{r1}+A_{r2}=1\) at every jointly possible point and every alpha level. The complementary entries are not independent fuzzy numbers; they are deterministic images of the same latent fuzzy variable.

For the four latent variables, the joint possibility convention used in this gate is the minimum t-norm, so their alpha-cut in latent space is a four-dimensional box. This is a structural triangular encoding of the already fixed full-scale marginal support. Alpha is a fuzzy-membership level, not a probability or confidence level.

**Scope boundary.** This construction preserves the deterministic compositional dependence within each matrix row. It does not preserve the empirical A–b pairing of the joint moving-block bootstrap. It corresponds to a fuzzy analogue of the existing closure-only mechanism, not a fully paired empirical joint fuzzy model.
